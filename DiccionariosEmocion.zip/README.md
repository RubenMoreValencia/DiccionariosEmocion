# DiccionarioEmocion

## Introducción

El paquete `DiccionarioEmocion` permite realizar análisis de emociones a partir de textos utilizando diccionarios léxicos (NRC, Bing, Afinn, Syuzhet) y modelos de aprendizaje automático. Proporciona un flujo completo desde la carga de datos, procesamiento de texto, valoración emocional, visualización, simulación y predicción de resultados emocionales.

Está diseñado para tareas de minería de texto en español e inglés y puede ser aplicado a estudios sociales, psicológicos, comunicacionales o políticos.

---

## FASE 1: Carga y preparación de textos

### Función: `UnirExcelITFF_Optimizada()`

- **Descripción**: Unifica archivos de texto desde Excel o CSV. Tokeniza, limpia, traduce y genera matrices simplificadas para análisis de emociones.
- **Parámetros**:
  - `nombreBase`: prefijo del nombre de los archivos (sin extensión).
  - `IndIni`, `IndFin`: índices para cargar archivos numerados.
  - `IdiomaIni`, `IdiomaFin`: idioma de origen y destino de la traducción.
  - `IdiomaLimpieza`: idioma para normalizar texto.
  - `valorPor`: umbral de palabras a conservar por frecuencia.
  - `SiTrad`: booleano que indica si se debe traducir el texto.
- **Valor Retornado**: Lista con matrices de texto limpio, tokens, emociones y estructura valorada.

```r
resultados <- UnirExcelITFF_Optimizada(
  nombreBase = "Data/DocMoreR/TiaMariaEn_",
  IndIni = 2, IndFin = 2,
  IdiomaIni = "en", IdiomaFin = "en",
  IdiomaLimpieza = "english",
  valorPor = 10,
  SiTrad = FALSE
)
```

---

## FASE 2: Valoración emocional con diccionarios

### Función: `MatrizValoradaXMetodo()`

- **Descripción**: Aplica diccionarios emocionales y devuelve una matriz con puntuaciones por token.
- **Parámetros**:
  - `tokens`: vector de palabras.
  - `usar_traduccion`: si se desea traducir antes de valorar (default = FALSE).
- **Salidas**: data frame con columnas de emociones (`anger`, `joy`, `trust`, etc.) y puntajes de distintos métodos.

```r
mvxm <- MatrizValoradaXMetodo(resultados$MatrizSimplificadaTokensValorados$MatrizCol0, FALSE)
```

---

## FASE 3: Resumen de palabras clave

### Función: `generar_resumen_palabras()`

- **Descripción**: Resume palabras frecuentes excluyendo irrelevantes.
- **Parámetros**:
  - `tokens`: vector de texto tokenizado.
  - `palabras_excluidas`: vector de palabras a ignorar.
- **Resultado**: tabla y gráfico con frecuencia absoluta y relativa.

```r
palabras_excluidas <- c("Tía","María","Bambas","bambas","tía","maría","rt","odebrecht","aldo","vizcarra")
resumen <- generar_resumen_palabras(resultados$TextoTokens_Rep, palabras_excluidas)
```

### Función: `analizar_frecuencia_palabras()`

- Traduce las palabras más frecuentes y visualiza las 20 principales.

```r
analizar_frecuencia_palabras(
  resultados$TextoTokens_Rep,
  palabras_excluidas,
  idioma_traduccion = "español",
  usar_chatgpt = TRUE,
  n_top = 20
)
```

---

## FASE 4: Reescalado emocional y semántico

### Funciones:

```r
df1 <- interseccionDataFrames(
  as.data.frame(resultados$VectorTextoSentimientosNRC),
  as.data.frame(resultados$MatrizSimplificadaTokensValorados$MatrizTranspuestaSinDup)
)

traducciones <- TraduceA(df1$NombreFilas, idioma_destino = "español")
dfx <- modificarNombresFilas(df1$TablaCompletaNRC, traducciones)

data <- analizar_comentarios_ReEscalado_general(dfx, columna_valor = 14)
```

- `interseccionDataFrames()`: cruza matrices NRC y simplificada.
- `TraduceA()`: traduce nombres de fila.
- `modificarNombresFilas()`: renombra filas con traducciones.
- `analizar_comentarios_ReEscalado_general()`: crea columnas `diferencia`, `categoria`, y `percentil`.

---

## FASE 5: Visualización de emociones

```r
graficar_pca_emociones(data)
graficar_emociones_agrupadas(data)
visualizar_curvas_sentimiento(data)
```

Cada una permite representar:

- Emociones principales en espacios reducidos (PCA).
- Agrupaciones de tokens similares emocionalmente.
- Evolución emocional en texto (curva tipo syuzhet).

---

## FASE 6: Simulación de modelos de predicción

```r
simular_rnn_regresion(data)
simular_comparacion_todos(data)
```

- Prueba modelos previamente entrenados.
- Compara múltiples modelos (regresión, SVM, red neuronal, etc.).

---

## FASE 7: Entrenamiento de modelos

```r
modelo <- ajustar_red_nn_unificada(data, columna_objetivo = "categoria")
```

Se puede usar `simular_red_nn_unificada()` para evaluar predicciones.

---

## FASE 8: Exportación de resultados

```r
guardarDataFrameCSV(data, "Resultados_Escalados.csv")
```

---

## Estudio de caso: Proyecto minero Tía María

Se analizaron noticias y tweets sobre el conflicto en Arequipa. Se detectaron emociones como `ira`, `tristeza`, `miedo` y se visualizó una tendencia de rechazo. El modelo `simular_comparacion_todos()` identificó categorías dominantes con precisión del 84%.

---

## Referencias

- Mohammad, S. & Turney, P. (2013). Crowdsourcing a Word-Emotion Association Lexicon.
- Syuzhet R package: https://github.com/mjockers/syuzhet
- NRC Emotion Lexicon: http://saifmohammad.com/WebPages/NRC-Emotion-Lexicon.htm

